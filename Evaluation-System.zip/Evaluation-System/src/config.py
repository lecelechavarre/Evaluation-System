"""
Application configuration and constants.

This module centralizes environment-driven settings, directory paths,
role constants, and rating bounds used across the application.
"""
from __future__ import annotations

import os
import secrets
from pathlib import Path
from typing import List

try:
    # Optional dependency; present in requirements.txt
    from dotenv import load_dotenv
except Exception:  # pragma: no cover - fallback if dotenv missing
    def load_dotenv(*args, **kwargs):  # type: ignore
        return False


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _truthy(value: str | None) -> bool:
    if value is None:
        return False
    return value.strip().lower() in {"1", "true", "yes", "y", "on"}


def _resolve_dir(path_like: str | Path, base: Path) -> Path:
    path = Path(path_like)
    return path if path.is_absolute() else (base / path)


# ---------------------------------------------------------------------------
# Base paths and environment
# ---------------------------------------------------------------------------

# Load .env if present
load_dotenv()

# Root directory of the repository
BASE_DIR: Path = Path(__file__).resolve().parent.parent

# Template directory (repo-level `templates/`)
TEMPLATES_DIR: Path = BASE_DIR / "templates"

# Data/logs/exports directories (can be overridden via env)
DATA_DIR: Path = _resolve_dir(os.getenv("DATA_DIR", "data"), BASE_DIR)
LOGS_DIR: Path = _resolve_dir(os.getenv("LOGS_DIR", "logs"), BASE_DIR)
EXPORTS_DIR: Path = _resolve_dir(os.getenv("EXPORTS_DIR", "exports"), BASE_DIR)

# Ensure directories exist
for _dir in (DATA_DIR, LOGS_DIR, EXPORTS_DIR):
    _dir.mkdir(parents=True, exist_ok=True)


# ---------------------------------------------------------------------------
# Security and session settings
# ---------------------------------------------------------------------------

SECRET_KEY: str = os.getenv("SECRET_KEY", "") or secrets.token_hex(32)
SESSION_LIFETIME_HOURS: int = int(os.getenv("SESSION_LIFETIME_HOURS", "8"))
PASSWORD_MIN_LENGTH: int = int(os.getenv("PASSWORD_MIN_LENGTH", "8"))

FLASK_DEBUG: bool = _truthy(os.getenv("FLASK_DEBUG", "true"))


# ---------------------------------------------------------------------------
# Role and rating constants
# ---------------------------------------------------------------------------

ROLE_ADMIN: str = "admin"
ROLE_EVALUATOR: str = "evaluator"
ROLE_EMPLOYEE: str = "employee"

VALID_ROLES: List[str] = [ROLE_ADMIN, ROLE_EVALUATOR, ROLE_EMPLOYEE]

MIN_RATING: int = int(os.getenv("MIN_RATING", "1"))
MAX_RATING: int = int(os.getenv("MAX_RATING", "5"))


# ---------------------------------------------------------------------------
# Data file paths
# ---------------------------------------------------------------------------

USERS_FILE: Path = DATA_DIR / "users.json"
CRITERIA_FILE: Path = DATA_DIR / "criteria.json"
EVALUATIONS_FILE: Path = DATA_DIR / "evaluations.json"

