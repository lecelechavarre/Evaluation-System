#!/usr/bin/env python3
"""
Simple smoke test for the Performance Evaluation System web app.
- Creates a test admin user if missing
- Logs in via Flask test client
- Visits dashboard, evaluations, criteria, reports
"""
from __future__ import annotations

import sys
from pathlib import Path

# Ensure src is on PYTHONPATH
ROOT = Path(__file__).parent.parent
SRC = ROOT / "src"
if str(SRC) not in sys.path:
    sys.path.insert(0, str(SRC))

# Imports from app
import config  # type: ignore
import web_app as web  # type: ignore

app = web.app
user_store = web.user_store
auth_manager = web.auth_manager

TEST_USERNAME = "test_admin"
TEST_PASSWORD = "Admin@1234!"

# Ensure test admin exists
if not user_store.find_by(username=TEST_USERNAME):
    user_id = auth_manager.create_user(
        username=TEST_USERNAME,
        password=TEST_PASSWORD,
        role=config.ROLE_ADMIN,
        full_name="Test Admin",
        email="test_admin@example.com",
    )
    assert user_id, "Failed to create test admin user"

# Run client flow
with app.test_client() as client:
    # Login
    resp = client.post(
        "/login",
        data={"username": TEST_USERNAME, "password": TEST_PASSWORD},
        follow_redirects=True,
    )
    assert resp.status_code == 200, f"Login failed: {resp.status_code}"
    assert b"Dashboard" in resp.data, "Did not reach dashboard after login"

    # Dashboard
    resp = client.get("/dashboard")
    assert resp.status_code == 200, "/dashboard failed"

    # Evaluations
    resp = client.get("/evaluations")
    assert resp.status_code == 200, "/evaluations failed"

    # Criteria
    resp = client.get("/criteria")
    assert resp.status_code == 200, "/criteria failed"

    # Reports (admin-only)
    resp = client.get("/reports")
    assert resp.status_code == 200, "/reports failed"

print("SMOKE_OK")
